function varargout = glogc1(varargin)

[varargout{1:nargout}] = xglogc(1, varargin{:});

end%

