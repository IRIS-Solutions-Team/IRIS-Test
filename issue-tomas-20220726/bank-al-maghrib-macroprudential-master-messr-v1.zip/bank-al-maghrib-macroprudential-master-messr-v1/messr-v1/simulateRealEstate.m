% binding LCR regulation

close all
clear
%#ok<*VUNUS>
%#ok<*CLARRSTR>

load mat/createModel.mat m

%% First simulation - increase in repi idiosyncratic component
d1 = steadydb(m, 1:40);
d1.shock_reid(1:4) = 0.05;

s1 = simulate( ...
    m, d1, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
);

smc1 = databank.minusControl(m, s1, d1);

%% Second simulation - decrease in repi idiosyncratic component
d2 = steadydb(m, 1:40);
d2.shock_reid(1:4) = -0.05;

s2 = simulate( ...
    m, d2, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
);

smc2 = databank.minusControl(m, s2, d2);

%% Third simulation - boom and bust 
d3 = steadydb(m, 1:40);

d3.shock_dl_y_tnd(1) =  2;
d3.shock_dl_y_tnd(9) = -2i;

s3 = simulate( ...
    m, d3, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
);

smc3 = databank.minusControl(m, s3, d3);



%% Reporting

ch = databank.Chartpack();
ch.Range = 0:40;
ch.TitleSettings = {"interpreter", "none"}; 
ch.Highlight = 1:4;
ch.ShowFormulas = true;
ch.PlotSettings = {"lineWidth", 2, "marker", ".", "markerSize", 6};

ch < "Output gap: 100*(y_gap - 1)";
ch < "Real new bank loans: 100*(new_l / py - 1)";
ch < "Lending conditions: 400*new_rl_full_gap";
ch < "NPL ratio: 100*ln_to_l";
ch < "Loan-to-GDP: 100*l_to_4ny";
ch < "CAR: 100*car";
ch < "Real estate price index: repi";
ch < "Real estate price index growth (% QoQ): 400*log(roc_repi)";
ch < "Policy rate: rp*400";
ch < "Repi gap (pp): repi_gap*100";
ch < "LGD Lambda (%): lambda_1*100";
ch < "Portfolio default rate (%): q*100";



draw(ch, smc1 & smc2 & smc3);
legend('Positive reid shock','Negative reid shock','Bubble');
