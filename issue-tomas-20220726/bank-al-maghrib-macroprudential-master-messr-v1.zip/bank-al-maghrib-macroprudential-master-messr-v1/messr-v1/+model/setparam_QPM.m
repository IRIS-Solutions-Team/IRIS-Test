function p = setparam()
% Sets QPM model parameters

%% Policy / regime parameters
p.aa  = 1.5;
p.aa1 = 6.0;   % net export
p.aa2 = 1.5;   % remit
p.aa3 = 1.0;   % FX res
p.aa4 = 2.5;   % prem

% Which instruments do we use? 
% 0 = we use FX; 1 = we use interest rate.
% Note that alpha can be in the interval [0; 1]
p.FX_objective = 1;

% Which instruments do we use? 
% 0 = we use FX; 1 = we use interest rate.
% Note that alpha can be in the interval [0; 1]
p.alpha = 0.25; % 0 = fix, 1 = float

%% Non-linearity in core Phillips Curve

% 1 = convex term for output gap in core Phillips curve
% 0 = linear term for output gap in core Phillips curve
p.nlpcswitch = 1; 

%% Other parameters
% weights
p.w_basket_eur  = 0.6;  % weight of EUR in the basket for peg 

p.w_cpi_ez      = 0.67;   % weight of EZ in foreign inflation
p.w_cpi_ch      = 0.16;   % weight of China in foreign inflation
p.w_cpi_us      = 0.00;   % weight of US in foreign inflation

p.w_ez_cpi_im   = 0.80;   % weight of EZ CPI in imported inflation  

p.w_core        = 0.62947; %May2020_Base Year change 100=2017
p.w_admin_fuel  = 0.02794;  
p.w_admin_xfuel = 0.21981; 
p.w_admin       = p.w_admin_fuel+ p.w_admin_xfuel ;

p.w_agr         = 0.1065080041; %0.112389345; %  weight of agriculture
p.w_c           = 0.580834614757; %0.580255904;
p.w_gov         = 0.190274169072;  %0.189745054;
p.w_ex          = 0.392424924625; %0.387346836;
p.w_im          = 0.485172814430;%0.49255436;
p.w_inv         = 1-p.w_c-p.w_gov-p.w_ex+p.w_im;
p.w_dd          = p.w_c+p.w_gov+p.w_inv;
p.w_nx          = p.w_ex-p.w_im;
p.w_nx_ex       = p.w_ex/p.w_nx;
p.w_nx_im       = p.w_im/p.w_nx;

p.w_dd_c        = p.w_c/(p.w_c+p.w_inv+p.w_gov);
p.w_dd_gov      = p.w_gov/(p.w_c+p.w_inv+p.w_gov);
p.w_dd_inv      = 1-p.w_dd_c-p.w_dd_gov;

p.w_i           = 0.47;

% Steady-states
p.ss_dl_c_tnd   = 3.3;
p.ss_dl_inv_tnd = 4.0;
p.ss_dl_gov_tnd = 3.0;
p.ss_dl_ex_tnd  = 6.5;
p.ss_dl_im_tnd  = 5.1;
p.ss_dl_y_tnd   = p.w_ex*p.ss_dl_ex_tnd-p.w_im*p.ss_dl_im_tnd+p.w_gov*p.ss_dl_gov_tnd+p.w_c*p.ss_dl_c_tnd+p.w_inv*p.ss_dl_inv_tnd; 
p.ss_dl_y_agr_tnd = 4.5;

p.ss_dl_qremit_tnd  = 2.6; %3;%100*log(1+3.2/100);

p.ss_prem            = 1.5; %2.5;
p.ss_dl_z_tnd        = 0.0; %1.0;  

p.ss_dl_cpi_us      = 100*log(1+2.2/100);
p.ss_dl_cpi_ez      = 100*log(1+1.9/100);
p.ss_dl_cpi_ch      = 100*log(1+2.0/100);
p.ss_dl_cpi_rc      = 100*log(1+2.5/100);

p.ss_dl_z_ez_us     = -0.5; 
p.ss_dl_z_ez_ch     = -1.0;
p.ss_dl_z_ez_rc     = -0.5;

p.ss_r_ez_tnd       = 0;
p.ss_i_ez           = p.ss_r_ez_tnd + p.ss_dl_cpi_ez;

p.ss_dl_qfood_tnd   = 0;
p.ss_dl_qoil_tnd    = 0;

p.ss_dl_eur_usd     = p.ss_dl_cpi_ez - p.ss_dl_cpi_us + p.ss_dl_z_ez_us;
p.ss_dl_cny_eur     = p.ss_dl_cpi_ch - p.ss_dl_cpi_ez - p.ss_dl_z_ez_ch;
p.ss_dl_rc_eur      = p.ss_dl_cpi_rc - p.ss_dl_cpi_ez - p.ss_dl_z_ez_rc;
p.ss_dl_cny_usd     = p.ss_dl_cny_eur + p.ss_dl_eur_usd;
p.ss_dl_rc_usd      = p.ss_dl_rc_eur  + p.ss_dl_eur_usd;

p.ss_dl_cpi_foreign = p.w_cpi_ez*p.ss_dl_cpi_ez + p.w_cpi_ch*(p.ss_dl_cpi_ch - p.ss_dl_cny_eur) + p.w_cpi_us*(p.ss_dl_cpi_us + p.ss_dl_eur_usd)+ (1-p.w_cpi_ez-p.w_cpi_ch-p.w_cpi_us)*(p.ss_dl_cpi_rc - p.ss_dl_rc_eur);

p.ss_dl_cpi_vf_tar       = 0;
p.ss_dl_cpi_admin_fuel   = 2;

p.ss_r_tnd = p.ss_r_ez_tnd + p.ss_dl_z_tnd - (1-p.w_cpi_ez)*p.ss_dl_z_ez_us + p.ss_prem;

%parameters
p.c1_dl_y_tnd       = 0.85;

% p.c1_l_c_gap  lag - SEE BELOW 
p.c2_l_c_gap        = 0.10; % expected
p.c3_l_c_gap        = 0.2;%0.35*2/3; % r_gap
p.c4_l_c_gap        = 0.3; % income channel
p.c5_l_c_gap        = 0.12; % remit share in income
p.c6_l_c_gap        = 0.075; % VA agriculture
p.c1_g_c_tnd        = 0.85; %lag

p.c1_l_qremit_gap   = 0.10; % lag
p.c2_l_qremit_gap   = 2.5; % foreign
p.c1_dl_qremit_tnd  = 0.85; %lag


p.c1_l_inv_gap = 0.3; %lag
p.c2_l_inv_gap = 0.5; %lag
p.c3_l_inv_gap = 0.9; %income
p.c4_l_inv_gap = 0.3; %tobinq
p.c5_l_inv_gap = 0.03; % agr_gap
p.c1_g_inv_tnd = 0.85; %lag

p.c1_tobinq = 0.7; %expected tobinq
p.c2_tobinq = 0.25; %expected income
p.c3_tobinq = 0.2; %r_gap

p.c1_l_gov_gap        = 0.50; % lag
p.c1_g_gov_tnd        = 0.80;

p.c1_l_ex_gap       = 0.40; % lag
p.c2_l_ex_gap       = 0.10; % expected
p.c3_l_ex_gap       = 1.5; % foreign gap
p.c4_l_ex_gap       = 0.4; %2; % reer gap
p.c5_l_ex_gap       = 0.02;
p.c1_g_ex_tnd       = 0.8;

p.c1_l_im_gap       = 0.4;%0.40; % lag
p.c2_l_im_gap       = 0.45;%0.35; % export
p.c3_l_im_gap       = 0.35; % cons
p.c4_l_im_gap       = 0.29; % inv
p.c5_l_im_gap       = 0.05; % oil price
p.c6_l_im_gap       = 0.1; % l_z_gap
p.c7_l_im_gap       = 0.05; % agr gdp

p.c1_g_im_tnd       = 0.8; %

p.c1_dl_y_agr_tnd   = 0.95; 
p.c1_l_y_agr_gap    = 0.6;


p.c1_dl_cpi_tar      = 0.99; % persistence of dl_cpi_tar
p.c1_prem            = 0.85; % persistence of premium
p.c2_prem            = 0.025;  % fx reserves
p.c1_dl_z_tnd        = 0.85;  % persistence of dl_z_tnd

%p.c1_dl_cpi_core - lag SEE BELOW
p.c2_dl_cpi_core = 0.2;  % rmc
p.c3_dl_cpi_core = 0.005;  % volatile food 

p.c1_rmc_core    = 0.595; % dd_gap
p.c2_rmc_core    = 0.175; % l_z_gap 
p.c3_rmc_core    = 0.04;  % l_qfood_gap 

p.c1_dl_cpi_admin_xfuel = 0.20; % lag
% c2_dl_cpi_admin_xfuel = 0.5; % expected 
p.c3_dl_cpi_admin_xfuel = 0.05; % gov_gap 
 
p.c1_dl_cpi_admin_fuel = 0.1;  % lag
p.c2_dl_cpi_admin_fuel = 0.4; % oil imported 

p.c1_dl_cpi_vf       = 0.3;
p.c2_dl_cpi_vf       = 0.075; 

p.c1_e_l_mad_eur = 0.85; % share of forward looking agents

% p.c1_ip - lag, SEE BELOW
% p.c2_ip - inflation deviation, SEE BELOW
p.c3_ip         = 0.30; % l_y_gap
p.c4_ip         = 0; % dl_mad_eur_dev

p.c1_ip_fix     = 0.85; %lag
p.c2_ip_fix     = 0.3;  % infl. dev.
p.c3_ip_fix     = 0.15; % l_y_gap

p.c1_dl_cpi_ch = 0.6;
p.c1_dl_cpi_us = 0.6;
p.c1_dl_cpi_rc = 0.6;

p.c1_l_y_ez_gap = 0.45;
p.c2_l_y_ez_gap = 0.5;
p.c3_l_y_ez_gap = 0.05;

p.c1_dl_cpi_ez=0.4;
p.c2_dl_cpi_ez=0.01;%0.025
p.c3_dl_cpi_ez=0; %0.014

p.c1_i_ez = 0.75;
p.c2_i_ez = 1.5;
p.c3_i_ez = 0.25;

p.c1_dl_eur_usd     = 0.3;
p.c1_dl_cny_usd     = 0.6;
p.c1_dl_rc_usd      = 0.3;

p.c1_r_ez_tnd   = 0.9;

p.c1_dl_qfood_tnd = 0.8;
p.c1_l_qfood_gap  = 0.5;
p.c1_dl_qoil_tnd  = 0.8;
p.c1_l_qoil_gap   = 0.50;

p.c1_dl_defl_imp = 0.4;
p.c2_dl_defl_imp = 0.2;
p.c3_dl_defl_imp = 0.1;

p.c1_dl_fx_cov_tnd = 0.9;

p.c1_l_fx_res_gap = 0.65; 
p.c2_l_fx_res_gap = 0.25;
p.c3_l_fx_res_gap = 1.5;


% standard errors of shocks
p.std_shock_dl_y_tnd        = 2; 
p.std_disc_dl_y_prod        = 0.5;

% p.std_shock_l_dd_gap        = 0.4;
% p.std_shock_dl_dd_tnd       = 0.3;

p.std_shock_l_c_gap        = 1.00; 
p.std_shock_g_c_tnd        = 0.5;
p.std_shock_l_c_tnd        = 0.01;

p.std_shock_l_qremit_gap   = 4.0;
p.std_shock_dl_qremit_tnd  = 0.8; 

p.std_shock_l_inv_gap        = 3; 
p.std_shock_g_inv_tnd        = 1.2;
p.std_shock_l_inv_tnd        = 0.01;

p.std_shock_l_gov_gap       = 0.9;
p.std_shock_g_gov_tnd       = 1; 
p.std_shock_l_gov_tnd       = 0.01; 

p.std_shock_l_ex_gap        = 2.5; 
p.std_shock_g_ex_tnd        = 1; 
p.std_shock_l_ex_tnd        = 0.01; 

p.std_shock_l_im_gap        = 1.5; 
p.std_shock_g_im_tnd        = 1;
p.std_shock_l_im_tnd        = 0.01;

p.std_shock_l_y_agr_gap     = 4; 
p.std_shock_dl_y_agr_tnd    = 3.0;

p.std_shock_ip              = 0.3; 
p.std_shock_dl_cpi_core     = 0.7;
p.std_shock_l_mad_eur       = 1.0;
p.std_shock_l_s_basket_tar  = 0.001;

p.std_shock_dl_cpi_disc     = 0.5;
p.std_shock_dl_cpi_admin    = 1;

p.std_shock_dl_z_tnd        = 0.3; 
p.std_shock_prem            = 0.75; 
p.std_shock_dl_cpi_tar      = 0.2;

p.std_shock_r_tnd           = 0.001;
p.std_shock_r_ez_tnd        = 0.1;

p.std_shock_dl_cpi_vf           = 10; 
p.std_shock_dl_cpi_admin_fuel   = 13; 
p.std_shock_dl_cpi_admin_xfuel  = 1.5;

p.std_shock_dl_defl_imp     = 9;

p.std_shock_l_c_tnd     = 0.05;
p.std_shock_l_gov_tnd     = 0.05;
p.std_shock_l_inv_tnd     = 0.05;
p.std_shock_l_ex_tnd     = 0.05;
p.std_shock_l_im_tnd     = 0.05;
p.std_shock_l_y_tnd     = 0.05;

% foreign sector
p.std_shock_dl_eur_usd      = 9.5; 
p.std_shock_dl_cny_usd      = 6.5;
p.std_shock_dl_rc_usd       = 9.5;
p.std_shock_dl_cpi_ez       = 0.8;
p.std_shock_dl_cpi_us       = 2.4; 
p.std_shock_dl_cpi_ch       = 1.9; 
p.std_shock_dl_cpi_rc       = 1.25;
p.std_shock_l_y_ez_gap      = 0.4;
p.std_shock_i_ez            = 0.3;

p.std_shock_l_qoil_gap      = 14;
p.std_shock_dl_qoil_tnd     = 1.5;
p.std_shock_l_qfood_gap     = 3.5; 
p.std_shock_dl_qfood_tnd    = 0.7;

p.std_shock_l_fx_res_gap    = 4.5;
p.std_shock_l_fx_cov_tnd    = 1.5;   


%% Special section: parameters that will change with MonPol regime
  
p.c1_l_c_gap_fx     = 0.45;
p.c1_l_c_gap_fl     = 0.65;  % more persistence so the MonPol has to work more
  
p.c1_dl_cpi_core_fx = 0.35; 
p.c1_dl_cpi_core_fl = 0.60;  % more persistence so the MonPol has to work more

p.c1_ip_fl          = 0.65;
p.c1_ip_fx          = 0.65;

p.c2_ip_fx          = 0.35;
p.c2_ip_fl          = 2.00; % more aggressive policy with IT

% For easier reporting
p.c1_l_c_gap        = (1-p.alpha)*p.c1_l_c_gap_fx     + p.alpha*p.c1_l_c_gap_fl;
p.c1_dl_cpi_core    = (1-p.alpha)*p.c1_dl_cpi_core_fx + p.alpha*p.c1_dl_cpi_core_fl;
p.c1_ip             = (1-p.alpha)*p.c1_ip_fx          + p.alpha*p.c1_ip_fl;
p.c2_ip             = (1-p.alpha)*p.c2_ip_fx          + p.alpha*p.c2_ip_fl;
  

p.c1_dl_im_tnd       = 0.85;
p.c1_dl_ex_tnd       = 0.85;
p.c1_dl_inv_tnd      = 0.85;
p.c1_dl_c_tnd        = 0.85;
p.c1_dl_gov_tnd      = 0.85;
end
