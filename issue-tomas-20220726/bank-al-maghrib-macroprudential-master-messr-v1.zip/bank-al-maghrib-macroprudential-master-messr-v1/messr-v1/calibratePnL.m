load mat/createModel.mat

% interest costs as % of GDP
% (d)         * rd{-1} 
100 * real(m.d) * real(m.rd) / real(m.ny)
100 * real(m.d) * 1/400 / real(m.ny)

% interest on credit as % of GDP
100*real(m.rl_1)*(real(m.lp0_1) + real(m.lnc0_1)) / real(m.ny)
100*5.5/400*(real(m.lp0_1) + real(m.lnc0_1)) / real(m.ny)

100 * (5.5/400*(real(m.lp0_1) + real(m.lnc0_1)) - real(m.d) * 1/400) / real(m.ny)

% all interest income as % of GDP, incl  market operations
a1 = real(m.rl_1)*(real(m.lp0_1) + real(m.lnc0_1));
a2 = real(m.oas) * real(m.roas); % income from other assets
a3 = real(m.oras)  * real(m.roras); % income from other risky assets
a4 = real(m.b)     * real(m.rb); % bond interest income
100*(a1 + a2 + a3 + a4) / real(m.ny)
100*(a2 + a3 + a4)/ real(m.ny)

% using actual interest rates for 2019
b1 = 5.5/400*(real(m.lp0_1) + real(m.lnc0_1));
b2 = real(m.oas)   * (real(m.roas)-1.25/400); % income from other assets
b3 = real(m.oras)  * (real(m.roras)-1.25/400); % income from other risky assets
b4 = real(m.b)     * (real(m.rb)-1.25/400); % bond interest income
100*(b1 + b2 + b3 + b4) / real(m.ny)
100*(b2 + b3 + b4)/ real(m.ny)


% costs: operations, taxes, etc.
100*1.6/400  * real(m.tag) / real(m.ny)


% overall net profit
100*(b1 + b2 + b3 + b4 - real(m.d) * 1/400 - real(m.w) ...
      - 1.6/400  * real(m.tag)) / real(m.ny)