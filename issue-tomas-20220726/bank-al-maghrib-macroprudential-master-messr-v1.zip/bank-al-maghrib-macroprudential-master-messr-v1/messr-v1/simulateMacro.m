% basic macro shocks

close all
clear
%#ok<*VUNUS>
%#ok<*CLARRSTR>

load mat/createModel.mat m

%% Demand shock
d = steadydb(m, 1:40);
d.shock_l_y_gap(1) = -2;

s1 = simulate( ...
    m, d, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
);

smc1 = databank.minusControl(m, s1, d);

%% Second simulation - supply shock
d = steadydb(m, 1:40);
d.shock_dl_cpi_core(1) = 2;


s2 = simulate( ...
    m, d, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
);


smc2 = databank.minusControl(m, s2, d);

%% Third simulation - potential growth shock
d = steadydb(m, 1:40);
d.shock_dl_y_tnd(1) = 2;


s3 = simulate( ...
    m, d, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
);


smc3 = databank.minusControl(m, s3, d);

%% Fourth simulation - interest rate
d = steadydb(m, 1:40);
d.shock_ip(1) = 2;


s4 = simulate( ...
    m, d, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
);


smc4 = databank.minusControl(m, s4, d);
%% Reporting

ch = databank.Chartpack();
ch.Range = 0:40;
ch.TitleSettings = {"interpreter", "none"}; 
ch.Highlight = 0:8;
ch.ShowFormulas = true;
ch.PlotSettings = {"lineWidth", 2, "marker", ".", "markerSize", 6};

ch < "Output: 100*(y - 1)"; 
ch < "Output gap: 100*(y_gap - 1)";
ch < "Potential output: 100*(y_tnd - 1)";
ch < "Forward output: 100*(fws_y - 1)";
ch < "Potential growth, PA: 400*(roc_y_tnd-1)";
ch < "Policy rate, PA: 400*rp";
ch < "Real bank loans: 100*(l / py - 1)";
ch < "Real new bank loans: 100*(new_l / py - 1)";
ch < "Credit risk (portfolio default rates): 100*q";
ch < "Lending conditions: 400*new_rl_full_gap";
ch < "Stock lending rates, PA: 400*rl";
ch < "Capital adequacy ratio: 100*car";
ch < "NPL ratio: 100*ln_to_l";
ch < "Return on assets: 400*roa";
ch < "Loan-to-GDP: 100*l_to_4ny";
ch < "Credit Gap Fw-looking: 100*l/(4*py*fws_y) - 100*l_to_4ny_tnd";
ch < "Capital adequacy risk surcharge: 400*rx";
ch < "Base rate: 400*rl_base_1";
ch < "Full risk rate: 400*new_rl_full_1";
ch < "Real Estate Price Index: repi";
ch < "Real Estate asset % of GDP: reas_to_4ny*100";
ch < "Bonds % of GDP: b_to_4ny*100";



draw(ch, smc1 & smc2 & smc3 & smc4);
legend('Demand','Supply','Potential','Policy rate');


