% simulation exploring impact of negative output gap shock on the level of
% defaults


close all
clear
%#ok<*CLARRSTR>
%#ok<*VUNUS>

load mat/createModel.mat m

%% first two simulations - baseline model calibration for credit risk fucntion

m1 = m;

d1 = steadydb(m1, 1:40);
d1.shock_l_y_gap(5) = -5;

s1 = simulate( ...
    m1, d1, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "anticipate", true ...
);

smc1 = databank.minusControl(m1, s1, d1);


d2 = steadydb(m1, 1:40);
d2.shock_l_y_gap(5) = -2.5;


s2 = simulate( ...
    m1, d2, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "anticipate", true ...
);

smc2 = databank.minusControl(m1, s2, d2);

%% next two simulations - baseline model calibration for credit risk fucntion

m2 = m;
m2.c1_q_1 = 0.017; 
m2.c2_q_1 = 0.035; 
m2.c3_q_1 = 2.29;
m2.c4_q_1 = 0.0101;
m2.c6_q_1 = 0.12;

% resolve the model
p.l_to_4ny_1   = 0.80;  % sstate loan-to-GDP ratio
p.ln_to_l_1    = 0.08;  % sstate NPL ratio
p.new_l_to_4ny = 0.06;  % approximate ratio of new loans to nominal GDP
p.b_to_4ny     = 0.16;  % sstate ratio of bonds to nominal GDP
p.lambda_1     = 0.6;

m2 = assign(m2, p);

swaps = [
    "l_to_4ny_1",       "ss_ivy_1"
    "new_l_to_4ny",     "theta_lp_1"
    "ln_to_l_1",        "c4_q_1"
    "b_to_4ny",         "ss_new_b_to_4ny"
    "lambda_1",         "c1_lambda_1"
];

m2 = steady( ...
    m2 ...
    , "exogenize", swaps(:, 1) ...
    , "endogenize", swaps(:, 2) ...
);

checkSteady(m2);

m2 = solve(m2);


d2 = steadydb(m2, 1:40);
d2.shock_l_y_gap(5) = -5;

s3 = simulate( ...
    m2, d2, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "anticipate", true ...
);

smc3 = databank.minusControl(m2, s3, d2);


d2 = steadydb(m2, 1:40);
d2.shock_l_y_gap(5) = -2.5;


s4 = simulate( ...
    m2, d2, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "anticipate", true ...
);

smc4 = databank.minusControl(m2, s4, d2);

%% Reporting

ch = databank.Chartpack();
ch.Range = 0:40;
ch.TitleSettings = {"interpreter", "none"}; 
ch.Highlight = 0:8;
ch.ShowFormulas = true;
ch.PlotSettings = {"lineWidth", 2, "marker", ".", "markerSize", 6};

ch < "Output: 100*(y - 1)"; 
ch < "Output gap: 100*(y_gap - 1)";
ch < "Potential output: 100*(y_tnd - 1)";
ch < "Forward output: 100*(fws_y - 1)";
ch < "Potential growth, PA: 400*(roc_y_tnd-1)";
ch < "Policy rate, PA: 400*rp";
ch < "Real bank loans: 100*(l / py - 1)";
ch < "Real new bank loans: 100*(new_l / py - 1)";
ch < "Credit risk (portfolio default rates): 100*q";
ch < "Lending conditions: 400*new_rl_full_gap";
ch < "Stock lending rates, PA: 400*rl";
ch < "Capital adequacy ratio: 100*car";
ch < "NPL ratio: 100*ln_to_l";
ch < "Return on assets: 400*roa";
ch < "Loan-to-GDP: 100*l_to_4ny";
ch < "Credit Gap Fw-looking: 100*l/(4*py*fws_y) - 100*l_to_4ny_tnd";
ch < "Capital adequacy risk surcharge: 400*rx";
% ch < "Base rate: 400*rl_base_1";
ch < "Full risk rate: 400*new_rl_full_1";
ch < "Real Estate Price Index: repi";
ch < "Bonds % of GDP: b_to_4ny*100";



draw(ch, smc1 & smc2 & smc3 & smc4);
legend('Orig model -5','Orig model -2.5','Alt model -5','Alt model -2.5');

