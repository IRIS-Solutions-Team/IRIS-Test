% binding LCR regulation

close all
clear
%#ok<*VUNUS>
%#ok<*CLARRSTR>

load mat/createModel.mat m

%% First simulation - LCR is not binding 
d1 = steadydb(m, 1:40);
d1.lcr(1:4) = 1.5;

p1 = Plan.forModel(m, 1:40);
p1 = exogenize(p1,  1:40, ["lcr"]);
p1 = endogenize(p1, 1:40, ["shock_lcr"]);

s1 = simulate( ...
    m, d1, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
    , "Plan", p1 ...
);

smc1 = databank.minusControl(m, s1, d1);

%% Second simulation - LCR is mildly binding 
d2 = steadydb(m, 1:40);
d2.lcr(1:4) = 1.2;

s2 = simulate( ...
    m, d2, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
    , "Plan", p1 ...
);

smc2 = databank.minusControl(m, s2, d2);

%% Third simulation - LCR is strongly binding 
d3 = steadydb(m, 1:40);
d3.lcr(1:4) = 1.05;

s3 = simulate( ...
    m, d3, 1:40 ...
    , "prependInput", true ...
    , "method", "stacked" ...
    , "solver", "quickNewton" ...
    , "blocks", false ...
    , "Plan", p1 ...
);

smc3 = databank.minusControl(m, s3, d3);

%% Reporting

ch = databank.Chartpack();
ch.Range = 0:40;
ch.TitleSettings = {"interpreter", "none"}; 
ch.Highlight = 1:4;
ch.ShowFormulas = true;
ch.PlotSettings = {"lineWidth", 2, "marker", ".", "markerSize", 6};

ch < "Output gap: 100*(y_gap - 1)";
ch < "Real bank loans: 100*(l / py - 1)";
ch < "New Loan-to-GDP: 100*new_l_to_4ny";
ch < "Lending conditions: 400*new_rl_full_gap";
ch < "NPL ratio: 100*ln_to_l";
ch < "Loan-to-GDP: 100*l_to_4ny";


draw(ch, smc1 & smc2 & smc3 );
legend('None','Mild','Strong');
