

% close all
clear

load mat/createModel.mat m


z = linspace(-0.10, 0.05, 100);
q  = glogc(-z, m.c1_q_1, m.c2_q_1, m.c3_q_1, m.c4_q_1, m.c4_q_1+m.c6_q_1);
q2 = glogc(-z, 0.017, 0.035, 2.29, 0.0101, 0.0101+0.12);

plot(z, [q' q2']);
title("Credit risk function");
xlabel("Macro and credit conditions index z");
ylabel("Quarterly portfolio default rate q");
legend('Current model calibration','Alternative');
grid on

